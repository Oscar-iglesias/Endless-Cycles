function goodNoteHit(id, direction, noteType, isSustainNote)
	if dadName == 'x' and boyfriendName == 'majin' then
			characterPlayAnim('x', animationList[direction+1]..'-alt', false);
	end
end